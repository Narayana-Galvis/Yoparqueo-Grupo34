function PieDePagina() {
    return(
        <div className="margen-left footer bg-secondary text-white w-100 py-2">
            <span>© 2021 YoParqueo - todos los derechos reservados</span>
        </div>
    )
}

export default PieDePagina