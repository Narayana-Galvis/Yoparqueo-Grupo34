function BotonCancelar() {
    return(
        <div className="BotonCancelar">
            <button className="btn btn-primary text-white rounded-pill" data-bs-dismiss="modal">Cancelar</button>
        </div>
    )
}

export default BotonCancelar