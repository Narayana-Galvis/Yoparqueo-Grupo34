import { useEffect, useState } from "react";
import BotonCancelar from "./BotonCancelar";
import axios from "axios"

export default function IngresarModal() {
    const [vehiculos, setVehiculos] = useState([])
    const [tipoVehiculo, setTipoVehiculo] = useState('')
    const [idCelda, setIdCelda] = useState(0)
    const [laPlaca, setLaPlaca] = useState('')

    const ingresar = function(ev){
        ev.preventDefault();
        let placa = sessionStorage.getItem('placa')
        let celdaVehiculo = null
        if(!placa) return console.error('No ha configurado una placa')
        if(!tipoVehiculo) return console.error('No ha elegido un tipo de vehículo')

        let resVehiculo = null
        axios(
            tipoVehiculo === 'carro' ?
            `/consultaCeldaCarro/${idCelda}`
            : tipoVehiculo === 'moto' ? `/consultarCeldasMoto/${idCelda}`
            : '/'
        )
        .then(res => {
            celdaVehiculo = res.data && res.data.length && res.data[0] || null
            if(!celdaVehiculo) throw console.error('No ha elegido una celda')
            resVehiculo = res.data
        })
        .then(() => {
            let data = {
                body: {
                    _id: resVehiculo && resVehiculo._id,
                    id_celda: resVehiculo && resVehiculo.id_celda,
                    placa,
                    estado: false,
                    idParqueadero: resVehiculo && resVehiculo.idParqueadero,
                    date: resVehiculo && resVehiculo.date,
                    __v: resVehiculo && resVehiculo.__v,
                }
            }
            
            if(tipoVehiculo === 'carro'){
                axios.patch(`/actualizarCelda/${idCelda}`, data)
                .then(res => console.info('res PUT::', res))
                .catch(err => console.error(err))
            }

            if(tipoVehiculo === 'moto'){
                axios.put(`/actualizarCeldaMoto/${idCelda}`, data)
                .then(res => console.info('res PUT::', res))
                .catch(err => console.error(err))
            }
        })
        .catch(err => console.error(err))
    }

    useEffect(function(){
        setLaPlaca(sessionStorage.getItem('placa'))
    }, [])
    
    useEffect(function(){
        axios(
            tipoVehiculo === 'carro' ?
            '/celdasCarro'
            : tipoVehiculo === 'moto' ? '/celdasMoto'
            : '/'
        )
        .then(res => setVehiculos(res.data))
        .catch(err => console.error('Petición falló::', err))
    }, [tipoVehiculo])

    return (
        <div className="IngresarModal">
            <div v-if="msg=='Dashboard'" className="modal fade" id="ingresarVehiculoModal" tabindex="-1" aria-labelledby="ingresarVehiculoModalLabel" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content p-3">
                        <div className="modal-header">
                            <h3 className="text-primary">Ingresar Vehiculo</h3>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form>
                            <div className="modal-body">
                                <div className="mb-3">
                                    <div className="row">
                                        <div className="col-md-12">
                                            <span className="text-muted">Placa</span>
                                            <p className="m-0 fs-4 fw-bolder">{laPlaca}</p>
                                            <hr/>
                                        </div>
                                        <div className="col-md-12">
                                            <div class="form-check">
                                                <input 
                                                    class="form-check-input" 
                                                    type="radio" 
                                                    name="flexRadioDefault" 
                                                    id="radioCarro"
                                                    onChange={() => setTipoVehiculo('carro')}
                                                />
                                                <label class="form-check-label" for="radioCarro">
                                                    Carro
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input 
                                                    class="form-check-input" 
                                                    type="radio" 
                                                    name="flexRadioDefault" 
                                                    id="radioMoto"
                                                    onChange={() => setTipoVehiculo('moto')}
                                                />
                                                <label class="form-check-label" for="radioMoto">
                                                    Moto
                                                </label>
                                            </div>
                                            <span className="text-muted d-block">Vehículo</span>
                                            <select className="w-100 form-select" onChange={e => setIdCelda(e.target.value)}>
                                                <option value={0}>0</option>
                                                {
                                                    vehiculos && vehiculos.length ?
                                                    vehiculos.map(vehi => {
                                                        return vehi.estado ?
                                                        <option key={vehi._id} value={vehi.id_celda}>
                                                            {vehi.id_celda}
                                                        </option>
                                                        : null
                                                    })
                                                    : <option disabled>Seleccionar...</option>
                                                }
                                            </select>
                                            <hr/>
                                        </div>
                                        <div className="col-md-12">
                                            <span className="text-muted">Hora de ingreso</span>
                                            <p className="m-0 fs-4 fw-bolder">{()=>{
                                                var fecha = new Date();
                                                return fecha.getUTCHours()+":"+fecha.getUTCMinutes();
                                            }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="modal-footer justify-content-center">
                                <BotonCancelar />
                                <button 
                                    type="submit" 
                                    className="btn btn-primary bg-primary text-white rounded-pill" 
                                    onClick={ev => ingresar(ev)}
                                >Ingresar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}
