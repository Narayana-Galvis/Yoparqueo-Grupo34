

export default function NotFound() {
    return (
        <div className="container text-center">
            <h1>
                404 Not Found
            </h1>
        </div>
    )
}
