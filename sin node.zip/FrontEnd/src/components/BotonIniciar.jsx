
function BotonIniiciar() {
        return(
            <div className="BotonIniciar">
                <button type="submit" className="btn btn-primary text-white rounded-pill nav-link align-middle">Iniciar sessión</button>
            </div>
        )
}

export default BotonIniiciar